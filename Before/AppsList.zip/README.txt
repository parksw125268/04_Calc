http://theopentutorials.com/tutorials/android/listview/how-to-get-list-of-installed-apps-in-android/
